package com.example.practical6

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.DialogFragment

class MyDialogFragment : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        return AlertDialog.Builder(requireContext())
            .setTitle("This is a Dialog...")
            .setMessage("This is a sub text of dialog!")
            .setPositiveButton("Samjha Kya?") { dialog, which ->
                Toast.makeText(context, "Shabash!!!", Toast.LENGTH_SHORT).show()
            }

            .setNegativeButton("No") { dialog, which ->
                Toast.makeText(context, "AREY!!", Toast.LENGTH_SHORT).show()
            }.create()
    }
}
