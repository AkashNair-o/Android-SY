package com.example.p8

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.practical8.MyService
import com.example.practical8.R
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startService = findViewById<Button>(R.id.startService)
        val stopService = findViewById<Button>(R.id.stopService)
        val sendNotification = findViewById<Button>(R.id.sendNotification)
        val checkBroadcastReceiver = findViewById<Button>(R.id.checkBroadcastReceiver)
        val serviceIntent = Intent(this, MyService::class.java)


        startService.setOnClickListener {
            startService(serviceIntent)
        }

        stopService.setOnClickListener {
            stopService(serviceIntent)
        }

        sendNotification.setOnClickListener {
            try {
                val notificationChannel: NotificationChannel
                val notificationManager: NotificationManager
                lateinit var builder: Notification.Builder
                val channelId = "tyit"
                val description = "practical8"

                notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                val intent = Intent(this, MainActivity::class.java)
                val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    notificationChannel = NotificationChannel(channelId, description, NotificationManager .IMPORTANCE_HIGH)
                    notificationChannel.lightColor = Color.BLUE
                    notificationChannel.enableVibration(true)
                    notificationManager.createNotificationChannel(notificationChannel)
                    builder = Notification.Builder(this, channelId)
                        .setContentTitle("Notification - Practical 8")
                        .setContentText("Test content, here...")
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setLargeIcon(BitmapFactory.decodeResource(this.resources, R.drawable.ic_launcher_background))
                        .setContentIntent(pendingIntent)
                }
                notificationManager.notify(12345, builder.build())
            }
            catch (e: Exception) {
                Log.e("ASA: ", e.message.toString())
            }
        }

        checkBroadcastReceiver.setOnClickListener {
            val connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo= connectivityManager.activeNetworkInfo

            if (networkInfo != null && networkInfo.isConnected) {
                if (networkInfo.type == ConnectivityManager.TYPE_MOBILE) {
                    Toast.makeText(this, "Device connected to Mobile data", Toast.LENGTH_LONG).show()
                }

                if (networkInfo.type == ConnectivityManager.TYPE_WIFI) {
                    Toast.makeText(this,"Device connected to WiFi", Toast.LENGTH_LONG).show()
                }
            }
            else {
                Toast.makeText(this,"You are Offline", Toast.LENGTH_LONG).show()
            }
        }
    }
}