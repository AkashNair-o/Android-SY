package com.example.practical5

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment

class Fragment1 : Fragment() {

    //quick command search : ctrl+shift+A
    override fun onAttach(context: Context) {
        super.onAttach(context)

        Toast.makeText(context, "Attached!!", Toast.LENGTH_LONG).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // return super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.fragment1, container, false)
    }
}

