package com.example.practical7

import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.util.Log
import android.widget.Toast
import com.example.practical_11.R


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // Programming Media API
        // create an instance of media player for audio playback
        val mediaPlayer: MediaPlayer = MediaPlayer.create(this, R.raw.music)


        // register all the buttons using their appropriate IDs
        val bPlay: Button = findViewById(R.id.playButton)
        val bPause: Button = findViewById(R.id.pauseButton)
        val bStop: Button = findViewById(R.id.stopButton)


        // handle the start button to start the audio playback
        bPlay.setOnClickListener {
            mediaPlayer.start()
        }

        // handle the pause button to put the MediaPlayer instance at the Pause state
        bPause.setOnClickListener {
            mediaPlayer.pause()
        }

        // handle the stop button to stop playing and prepare the media player instance for the next instance of play
        bStop.setOnClickListener {
            mediaPlayer.stop()
            mediaPlayer.prepare()
        }


        // Programming Telephone API

        // Check if the READ_PHONE_STATE permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
        {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_PHONE_STATE), 123)
        }
        else
        {
            val telephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            val phoneStateListener = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    super.onCallStateChanged(state, phoneNumber)

                    /**
                     * 0 - No Calls 🥲
                     * 1 - Ringing
                     * 2 - Out-Going Call 👉👈
                     */

                    val callState = telephonyManager.callState
                    Log.e("TAG1", "Calls:  ${callState.toString()}")

                }
            }

            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE)

        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            123 -> {

                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    Toast.makeText(this, "Permission Granted!!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Permission Required!!", Toast.LENGTH_LONG).show()
                }
                return
            }
        }
    }

}

// Log.e("TAG1", "CallState:  ${callState.toString()} from \n ${phoneNumber.toString()}")