package com.example.practical7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class DisplayActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display)

        val displayName = findViewById<TextView>(R.id.displayName)
        val backButton = findViewById<Button>(R.id.backButton)

        val name = intent.getStringExtra("name_Value")
        displayName.text = "Class Class - $name!"


    }
}