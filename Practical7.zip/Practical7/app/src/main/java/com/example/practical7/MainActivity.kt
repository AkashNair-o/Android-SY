package com.example.practical7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val submitButton = findViewById<Button>(R.id.submitButton)
        val inputName = findViewById<EditText>(R.id.inputName)

        submitButton.setOnClickListener {
            val name = inputName.text.toString()

            val intent = Intent(this, DisplayActivity::class.java)
            intent.putExtra("name_Value", name)
            startActivity(intent)
        }

        inputName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // No action needed before text changed
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // No action needed while text is changing
            }

            override fun afterTextChanged(s: Editable?) {
                // Enable the submitButton only if there is some text in the nameEditText
                submitButton.isEnabled = !s.isNullOrEmpty()
            }
        })


    }
}