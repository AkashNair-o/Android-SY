package com.example.practical3

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.btnClick_explicit_intent

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Explicit Intent
        btnClick_explicit_intent.setOnClickListener {

            // 2 params
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        Toast.makeText(this, "Hello, Welcome!!", Toast.LENGTH_LONG).show()

    }
}
