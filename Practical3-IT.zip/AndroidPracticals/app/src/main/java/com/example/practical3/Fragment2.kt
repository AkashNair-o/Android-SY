package com.example.practical3

import androidx.fragment.app.Fragment

class Fragment2 : Fragment(R.layout.fragment2) {
}