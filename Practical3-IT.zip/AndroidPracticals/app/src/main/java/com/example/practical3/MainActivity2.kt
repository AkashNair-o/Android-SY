package com.example.practical3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.activity_main.btnClick_explicit_intent
import kotlinx.android.synthetic.main.activity_main2.btnClick_fragment1
import kotlinx.android.synthetic.main.activity_main2.btnClick_fragment2


class MainActivity2 : AppCompatActivity()
{

    // https://www.youtube.com/shorts/TLGbB0iMCjs?feature=share
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        btnClick_fragment1.setOnClickListener {
            replaceFragment(Fragment1())
        }

        btnClick_fragment2.setOnClickListener {
            replaceFragment(Fragment2())
        }

    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragmentMain, fragment)
        fragmentTransaction.commit()

    }
}