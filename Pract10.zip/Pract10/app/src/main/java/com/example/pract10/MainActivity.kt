package com.example.pract10

import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById<TextView>(R.id.textView)

        // Example of creating a new thread
        Thread {
            // Perform background task
            Thread.sleep(3000) // Simulate some background work
            val result = "Task completed on separate thread"
            // Update UI with result on the main thread
            runOnUiThread {
                textView.text = result
            }
        }.start()

        // Example of using a handler to update the UI from a background thread
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            // Update UI components here
            textView.text = "Task completed with Handler"
        }, 5000)

        // Example of using AsyncTask to perform background task
        MyAsyncTask(textView).execute()

        // Example of using Kotlin coroutine
        val coroutineHandler = Handler(Looper.getMainLooper())
        coroutineHandler.postDelayed({
            // Execute a coroutine on the main thread
            // Coroutine launches a background task and updates UI with the result
            updateTextViewWithCoroutine()
        }, 7000)
    }

    private fun updateTextViewWithCoroutine() {
        // Coroutine runs on the main thread by default
        textView.text = "Task completed with Coroutine"
    }

    // AsyncTask to perform background task
    private class MyAsyncTask(private val textView: TextView) : AsyncTask<Void, Void, String>() {
        override fun doInBackground(vararg params: Void?): String {
            // Perform background task
            Thread.sleep(4000) // Simulate some background work
            return "Task completed with AsyncTask"
        }

        override fun onPostExecute(result: String) {
            // Update UI with the result
            textView.text = result
        }

        override fun onPreExecute() {
            super.onPreExecute()

            textView.text = "result"
            Thread.sleep(2000) // Simulate some background work
        }
    }


}